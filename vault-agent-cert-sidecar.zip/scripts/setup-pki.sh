#!/bin/bash

vault secrets enable -path=pki_root pki
vault write pki_root/root/generate/internal common_name="root-ca" ttl=87600h

vault secrets enable -path=pki_int pki
vault write pki_int/intermediate/generate/internal common_name="int-ca"
vault write pki_root/root/sign-intermediate csr=@int.csr.pem format=pem_bundle ttl="43800h"
vault write pki_int/intermediate/set-signed certificate=@intermediate.cert.pem